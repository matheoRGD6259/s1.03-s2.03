# Réponses SAE 2.03

Ce document compile les réponses détaillées aux questions de la première semaine de la SAE 2.03, portant sur l'administration système sous Debian et la virtualisation.

---

## Question 1 : Architecture et Configuration Réseau

### 1.1 Architecture 64 bits
* **Définition** : L'appellation "Debian 64-bit" signifie que le système d'exploitation est encodé sur une architecture 64 bits (et non 32 bits).
* **Avantage** : Cette architecture permet au système de gérer et d'utiliser plus de 4 Go de mémoire RAM, ce qui est le standard pour les processeurs modernes (architecture amd64). [Source : [lemagit](https://www.lemagit.fr/definition/64-bits)]

![Création de la VM Debian 64 bits](1.png)

### 1.2 Configuration Réseau et DHCP
* **Protocole** : La configuration réseau par défaut de Debian utilise le DHCP (Dynamic Host Configuration Protocol).
* **Fonctionnement** : Ce protocole permet de fournir automatiquement une adresse IP (Internet Protocol) ainsi que d'autres informations de configuration pertinentes à un hôte IP dès son démarrage.
* **Paramètres de la VM** : 
  * L'interface réseau virtuelle utilise le mode **NAT** (Network Address Translation) configuré par défaut sur VirtualBox.
  * La commande `ip a` permet de vérifier que la machine virtuelle a obtenu l'adresse IPv4 `10.0.2.15/24` sur son interface principale.
  * L'adresse IPv4 de la passerelle (gateway) pour sortir sur Internet est `10.0.2.2`.

### 1.3 Prérequis Matériels (RAM)
* **Avec Interface Graphique** : Il est recommandé de disposer de **2 Go (2048 Mo) de RAM** pour utiliser confortablement l'environnement de bureau.
* **Sans Bureau (Mode Console)** : Avec 512 Mo de RAM, si la partition "swap" (mémoire virtuelle) est activée, le système peut tourner avec seulement 256 Mo de RAM en l'absence d'interface graphique. Toutefois, le système sera très lent car il devra utiliser le disque dur pour compenser le manque de mémoire vive. [Source : [Debian](https://www.debian.org/releases/stable/amd64/ch03s04.fr.html)]

![Récapitulatif de la configuration matérielle (RAM et Disque)](5.png)

---

## Question 2 : Concepts et Services

### 2.1 Virtualisation et Fichiers
* **Fichier ISO** : Il s'agit d'une "image" disque, c'est-à-dire une copie conforme d'un support optique tel qu'un CD ou un DVD, utilisée ici pour l'installation du système.

![Chargement des composants depuis l'ISO](4.png)

* **Environnements de bureau** : MATE et GNOME sont des environnements de bureau. Ils ont pour rôle de fournir l'interface graphique du système, incluant les fenêtres, les icônes et les barres des tâches pour rendre le système utilisable à la souris.

![Environnement de bureau Debian après installation](fin.png)

### 2.2 Serveurs et Proxy
* **Serveur Web** : C'est un logiciel qui fournit des ressources web, fonctionnant sur un serveur informatique pour répondre aux requêtes du World Wide Web via un réseau (public ou privé), en utilisant principalement le protocole HTTP. [Source : [Mozilla](https://developer.mozilla.org/fr/docs/Learn_web_development/Howto/Web_mechanics/What_is_a_web_server)]
* **Proxy (Serveur Mandataire)** : C'est un composant logiciel agissant comme un intermédiaire entre deux hôtes pour faciliter ou surveiller leurs échanges. Il est souvent utilisé pour accéder à Internet en masquant l'identité de l'utilisateur ou en filtrant les requêtes. [Source : [Wikipedia](https://fr.wikipedia.org/wiki/Proxy)]

### 2.3 Accès Sécurisé (SSH)
* **Logiciel** : Le serveur SSH installé sur les machines virtuelles est **OPENBSD Secure Shell server**, vérifiable en utilisant la commande `systemctl status ssh`.
* **Dépannage** : Si la connexion SSH à la session est impossible, c'est généralement parce que la clef hôte n'est pas reconnue par le client.

---

## Question 3 : Administration et Gestion des Droits

![Interface de connexion TTY en ligne de commande](7.jpg)

### 3.1 Gestion des Groupes
* Pour lister l'ensemble des groupes auxquels un utilisateur spécifique appartient (et donc connaître ses droits), il faut utiliser la commande `groups user`.

### 3.2 Différence entre `su` et `sudo`
* **La commande `su`** : Demande le mot de passe de l'utilisateur `root` afin d'ouvrir une session complète en tant qu'administrateur.
* **La commande `sudo`** : À l'inverse, demande le mot de passe admin pour exécuter une commande unique avec des privilèges élevés. C'est la méthode recommandée car plus sécurisée.

---

## Question 4 : Système, Noyau et Projet Debian

### 4.1 Noyau et VirtualBox Guest Additions
* **Version du Noyau** : La commande `uname -r` indique la version actuelle : `6.12.69+deb13-amd64`. Ici, `6.12.69` signifie la version du noyau, `deb13-amd64` indique que l'on utilise Debian 13 sur un processeur 64 bits.
* **Suppléments invités (Guest Additions)** : Ce sont des pilotes et logiciels qui améliorent l'intégration entre la VM et le système hôte (ajustement automatique de la résolution de l'écran, presse-papier partagé).
* **La commande `mount`** : Elle permet de "monter" un système de fichiers en créant un point de montage. Dans notre cas, elle permet de monter l'ISO des Suppléments invités dans la VM pour lancer l'installation via `VBoxLinuxAdditions.run`.

### 4.2 Le Projet Debian : Versions et Cycle de Vie
* **Le Projet** : Le projet Debian est une association d'individus ayant pour cause commune la création d'un système d'exploitation libre. Les noms des versions sont historiquement issus du film Toy Story. [Source : [Debian](https://www.google.com/search?q=https://www.debian.org/doc/manuals/debian-faq/ftparchives.fr.html%23sourceforcodenames)]
* **Versions actuelles et futures** :
  * Debian maintient simultanément au moins trois versions : Stable (**Trixie**), Testing (**Forky**) et Unstable (**Sid**).
  * La version Trixie prend en charge 6 architectures matérielles différentes.
  * En 2026, le dernier nom de code annoncé est **Macaroni**. [Source : [Debian](https://www.debian.org/releases/)]
* **Cycle de support** :
  * Mises à jour de sécurité officielles pendant la durée de la version "stable" (~3 ans).
  * Support **LTS** (Long Term Support) qui étend la vie de la version à 5 ans.
  * Programme **ELTS** (Extended LTS) pour prolonger la maintenance jusqu'à 10 ans. [Source : [Debian](https://wiki.debian.org/fr/LTS)]

---

## Annexe : Automatisation et personnalisation (Preseed & ISO)

Dans le cadre de l'automatisation du déploiement, des fichiers de configuration et des commandes spécifiques ont été utilisés pour modifier le comportement de l'installateur :

![Édition du fichier de configuration preseed-fr.cfg](8.jpg)
*Fichier preseed définissant les paquets à installer automatiquement.*

![Modification de l'image ISO avec la commande sed](2.png)
![Paramètres avancés d'édition de l'ISO](3.png)
*Manipulation de l'ISO Debian personnalisée en ligne de commande.*

---

## Question 5 : Automatisation de l'installation

Toute modification structurelle de l'installation automatique s'effectue au sein du fichier de configuration `preseed-fr.cfg`.

### 5.1 Configuration logicielle (Preseed)
* **Différence entre `pkgsel/include` et `tasksel`** : `pkgsel/include` installe des paquets unitaires (ex : git), alors que `tasksel` installe des groupes de fonctions cohérents (ex : un environnement de bureau complet).
* **Sécurité du preseed** : Le fichier est sensible car il peut contenir des identifiants ou des hashs de mots de passe. Il doit donc être stocké sur un réseau sécurisé durant le déploiement.

### 5.2 Modifications apportées
Nous avons enrichi la section `pkgsel` et `passwd` du fichier de configuration :
* Intégration de `sudo` dans la liste `pkgsel/include`.
* Ajout de `sudo` dans `passwd/user-default-groups` pour garantir un accès administratif immédiat dès le premier démarrage de la machine.

---

## Gestion de Version avec Git

### 1. Concepts théoriques
* **Différence Git / Plateformes (GitHub/Gitlab,...)** : Git est le moteur local de versioning ; GitHub/GitLab sont des serveurs distants offrant des services collaboratifs autour de Git.
* **Dépôt local** : L'ensemble des données et de l'historique réside dans le répertoire masqué `.git`.
* **Commit / Branche / Tag** :
  * Commit : Instantané immuable du code.
  * Branche : Ligne de développement parallèle.
  * Tag : Marqueur nommé (ex: v1.0) sur un commit spécifique.

### 2. Architecture Réseau
Git communique via `SSH` (port 22), `HTTPS` (port 443) ou le protocole natif `git` (port 9418). L'authentification SSH nécessite la génération d'une paire de clés (`ssh-keygen`) et l'ajout de la clé publique sur le serveur.

### 3 & 4. Pratique et Collaboration
* **.gitignore** : Fichier déterminant les éléments à exclure de l'index (ex: `*.class` pour Java).
* **Pull Request** : Mécanisme de revue de code permettant de proposer des modifications avant leur fusion dans la branche principale.
* **Git Blame** : Commande identifiant l'auteur et le commit pour chaque ligne d'un fichier.

### 5 & 6 & 7. Outils Graphiques
* **Interfaces natives** : `gitk` (visualisation d'historique) et `git-gui` (gestion des commits).
* **Comparaison** : Si la ligne de commande (CLI) offre une rapidité et une précision supérieures pour les scripts, les interfaces graphiques facilitent grandement la résolution visuelle des conflits de fusion (merges).