# README - SAÉ 2.03

## Membres de l’équipe
* GEORGE Mylan
* POUGHEON Enzo
* RINGARD Mathéo

## Comment nous avons converti nos fichiers :
Nous avons rédigé notre rapport au format **Markdown** (`.md`). Sa conversion vers les formats finaux s'effectue directement en ligne de commande à l'aide de l'outil Pandoc (nous n'utilisons pas de script d'automatisation).

Pour générer les fichiers depuis l'invite de commande (`cmd`), placez-vous dans le dossier contenant les sources et exécutez :

* **Pour la page web (HTML) :** `pandoc Rapport.md -s -o Rapport.html`
* **Pour le document (PDF) :** Soit via la commande `pandoc Rapport.md -o Rapport.pdf` (nécessite un moteur PDF configuré tel que wkhtmltopdf).
## Outils nécessaires à l’installation
Pour pouvoir recompiler le document à partir des sources, l'environnement suivant doit être mis en place sur la machine :

* **Pandoc** : Le convertisseur de documents principal.
*  **wkhtmltopdf** : Moteur de rendu nécessaire uniquement si l'on souhaite générer le PDF directement en ligne de commande avec Pandoc.
